/**
 * idv.jiangsir.JsonBean - TestJson.java
 * 2011/7/24 下午10:58:44
 * nknush-001
 */
package tw.zerojudge.Server.Beans;

/**
 * @author jiangsir
 * 
 */
public class TestJson {
	private String account;
	private String username;

	public String getAccount() {
		return account;
	}

	public void setAccount(String account) {
		this.account = account;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

}
