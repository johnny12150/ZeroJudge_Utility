// JavaScript Document
jQuery(document).ready(function() {
	jQuery("#submit").click(function(){
		$("#form1").submit();
	});
});
