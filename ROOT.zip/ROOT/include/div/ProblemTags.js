jQuery(document).ready(function() {
	jQuery("form[name='searchKeyword']").click(function() {
		$(this).submit();
	});
});
